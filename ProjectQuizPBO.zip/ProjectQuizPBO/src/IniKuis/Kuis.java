
package IniKuis;

public interface Kuis {
    void tampilkanSoal();
    int nilaiJawaban(String jawaban);

    public int getSkor();

    public boolean isFinished();


}

